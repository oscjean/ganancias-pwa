# App de Ganancias (PWA)

Esta es una aplicación web progresiva (PWA) que permite calcular, almacenar y visualizar tus ganancias.

## Cómo usar
1. Sube este repositorio a GitHub
2. Activa GitHub Pages desde la rama `main` en la carpeta `/ (root)`
3. Accede a la app desde el navegador móvil
4. Agrega a la pantalla de inicio para instalar como app

